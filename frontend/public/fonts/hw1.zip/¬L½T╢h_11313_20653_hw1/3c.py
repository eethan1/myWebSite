import pulp

N, M, T = 3,4,5
Ns = range(1, N+1)
Ms = range(1, M+1)
Ts = range(1, T+1)
k = lambda a,b : a*10+b

NMs = [k(i,j) for i in Ns for j in Ms]

K = {
    1:6,
    2:6,
    3:7,
}

D = {
    1:7,
    2:7,
    3:8,
    4:8,
}

P = {
    11:50,
    12:50,
    13:50,
    14:50,
    21:45,
    22:45,
    23:45,
    24:40,
    31:35,
    32:35,
    33:45,
    34:40,
}

F = {
    1:200,
    2:300,
    3:300
}

xs = LpVariable.dicts("x",NMs,0)
ys = LpVariable.dicts("y",[i for i in Ns],0)

xhs = LpVariable.dicts("x'",NMs,0)

prob = LpProblem("Oil Distribution Plan", LpMaximize)

prob += lpSum(T*[xs[i]*P[i] for i in NMs]) + lpSum((10-T)*[xhs[i]*P[i] for i in NMs]) - lpSum([F[i]*ys[i] for i in Ns])

for j in Ms:
    prob += lpSum([xs[k(i,j)] for i in Ns]) <= D[j]
for i in Ns:
    prob += lpSum([xs[k(i,j)] for j in Ms]) <= K[i]
for j in Ms:
    prob += lpSum([xhs[k(i,j)] for i in Ns]) <= D[j]
for i in Ns:
    prob += lpSum([xhs[k(i,j)] for j in Ms]) <= K[i] + ys[i]
    
    
prob.solve()
print("Status", LpStatus[prob.status])
print(f"Max:{prob.objective.value()}")
for v in prob.variables():
    print(v.name,'=', v.varValue) 
