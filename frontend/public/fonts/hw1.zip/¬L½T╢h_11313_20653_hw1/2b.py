import pulp
w = [1,3,2,0,0,0]
varnames = [str(i) for i in range(1,7)]

c1 = {
    '1':1,
    '2':1,
    '3':0,
    '4':1,
    '5':0,
    '6':0
}
c2 = {
    '1':1,
    '2':2,
    '3':1,
    '4':0,
    '5':-1,
    '6':0
}
c3 = {
    '1':0,
    '2':0,
    '3':1,
    '4':0,
    '5':0,
    '6':-1
}

vars = LpVariable.dicts("x",varnames,0)

prob = LpProblem("Linear Program", LpMaximize)

prob += lpSum([vars[i] for i in varnames])

prob += lpSum([c1[i]*vars[i] for i in varnames]) == 3
prob += lpSum([c2[i]*vars[i] for i in varnames]) == 10
prob += lpSum([c3[i]*vars[i] for i in varnames]) == 2

prob.solve()

print("Status", LpStatus[prob.status])
for v in prob.variables():
    print(v.name,'=', v.varValue) 
